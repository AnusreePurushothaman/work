require('./models/db')
const express=require('express')
var app=express()
const employeeController=require('./controllers/employeeController')
const Handlebars = require('handlebars')
const path=require("path")
const exphbs=require('express-handlebars')
const {allowInsecurePrototypeAccess} = require('@handlebars/allow-prototype-access')
const bodyparser=require('body-parser')

expressSession = require('express-session')

cookieParser = require('cookie-parser');
app.use(bodyparser.urlencoded({
	extended:true
}))


app.use(bodyparser.json())
app.set('views',path.join(__dirname,'/views/'));
app.engine('hbs', exphbs.engine({extname:'hbs',defaultLayout:'mainlayout',layoutsDir:__dirname +'/views/layouts/',handlebars: allowInsecurePrototypeAccess(Handlebars)}))
app.set('view engine','hbs')
app.use('/',employeeController)

app.use(cookieParser());
app.use(expressSession({
    secret: 'mYsEcReTkEy',
    resave: true,
    saveUninitialized: false,
}))

app.listen(3000,()=>{
	console.log("started")
})



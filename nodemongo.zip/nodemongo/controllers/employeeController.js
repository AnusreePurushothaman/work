const express=require('express')
const router=express.Router()
const mongoose=require('mongoose')
const Employee=mongoose.model('Employee')
const jwt =require('jsonwebtoken')
const exceljs=require('exceljs')

router.get('/',(req,res)=>{
	res.render("employee/index")
})
router.get('/register',(req,res)=>{
	res.render("employee/addOrEdit",{viewtitle:"Register here"})
})

router.get('/login',(req,res)=>{
	res.render("employee/login",{viewtitle:"Login"})
})

router.post('/employee',(req,res)=>{
	insertRecord(req,res)
})

router.post('/employeeupdate',(req,res)=>{
		updateRecord(req,res)
})

router.post('/logfn',(req,res)=>{
	getLogin(req,res)
})


function insertRecord(req,res){
var employee=new Employee()
console.log("jbnnn")
employee.fullName=req.body.name;
employee.qualification=req.body.qualification;

employee.email=req.body.email
employee.mobile=req.body.mobile
employee.city=req.body.city
employee.password=req.body.password

employee.save((err,doc)=>{
	if (!err){
		res.redirect('login')
	}
	else{
		if(err.name== 'ValidationError'){
			handleValidationError(err,req.body)
			res.render("employee/addOrEdit",{viewtitle:"Insert employee",employee:req.body})
			
			console.log(req.body)

		}
		else
		console.log(err)
	}
})}


function updateRecord(req,res){
	Employee.findOneAndUpdate({_id:req.body._id},req.body,{new:true},(err,doc)=>{
		if(!err){
			res.render('employee/userpage',{listt:doc})
		}
		else{
		if(err.name== 'ValidationError'){
			handleValidationError(err,req.body)
			res.render("employee/addOrEdit",{viewtitle:"Insert employee",employee:req.body})
			
			console.log(req.body)

		}
		else
		console.log(err)
	}

	})
}


function getLogin(req,res){
console.log("jbnnn")
var email=req.body.email
var password=req.body.password
Employee.findOne({$and:[{email:email},{password:password}]},(err,docs)=>{
	if (!err){

				if(email==="employeeadmin@gmail.com" & password==='admin'){
					res.redirect('list')
				}
				else{
				let token=jwt.sign({name:docs.email},'verySecretValue',{expiresIn:'1h'})
				console.log(token)
				if(token){
					return res.render('employee/userpage',{listt:docs})
					
				}
				
				}
	}else{
		res.render("employee/login",{viewtitle:"No user found"})
	}
	
})
}

router.get('/list',(req,res)=>{
	Employee.find({'email': {$ne : "employeeadmin@gmail.com"}},(err,docs)=>{
		console.log(docs)
		if (!err){
			res.render("employee/listemp",{listt:docs})
			console.log(docs)
		}
		else{
			console.log(err)
		}
	})
})

function handleValidationError(err,body){
	for (field in err.errors)
	{
		switch(err.errors[field].path){
			case 'fullName':
				body['fullNameError']=err.errors[field].message
				break;
			case 'email':
				body['emailError']=err.errors[field].message
				break;
			default:
				break
		}
	}
}


router.get('/deleteuser/:id',(req,res)=>{
	const id=req.params.id
	Employee.findByIdAndRemove(id,(err,doc)=>{
		if(!err){
			Employee.find({'email': {$ne : "employeeadmin@gmail.com"}},(err,docs)=>{
		console.log(docs)
		if (!err){
			res.render("employee/listemp",{listt:docs})
			console.log(docs)
		}
		else{
			console.log(err)
		}
	})
		}
		else{
			console.log(err)
		}
	})
})


router.get('/edituser/:id',(req,res)=>{
	const id=req.params.id
	Employee.findById(id,(err,docs)=>{
		if(!err){
			res.render('employee/editprofile',{editd:docs})
		}
		else{
			console.log(err)
		}
	})
})


router.get('/exportdata',(req,res)=>{
	Employee.find({'email': {$ne : "employeeadmin@gmail.com"}},(err,docs)=>{
	const workbook=new exceljs.Workbook()
	const worksheet=workbook.addWorksheet('employee details')
	worksheet.columns=[
{header:'Name', key:'fullName',width:30},
	{header:'Qualification', key:'qualification',width:30},
	{header:'Mobile', key:'mobile',width:15},

	{header:'Email', key:'email',width:30},
	{header:'City', key:'city',width:15},

	]
	docs.forEach((user)=>{
	worksheet.addRow(user)

	})
	worksheet.getRow(1).eachCell((cell)=>{
		cell.font={bold:true}
	})
	const data = workbook.xlsx.writeFile('data downloads/employees.xlsx').then(function(){
		res.download('data downloads/employees.xlsx',function(err){
			console.log(err)
		})
	})
	})
})


module.exports=router


















